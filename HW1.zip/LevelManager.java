import java.util.ArrayList;
import java.util.List;

public class LevelManager {
    private int level;
    private List<Enemy> enemies;
    private List<String> items;

    private void initializeLevel() {
        enemies.clear();
        items.clear();
        if (level == 1) {
            enemies.add(new Enemy("Skeleton", 50, 10));
            items.add("Health Elixir");
        } else if (level == 2) {
            enemies.add(new Enemy("Zombie", 70, 15));
            items.add("Magic Scroll");
        } else if (level == 3) {
            enemies.add(new Enemy("Vampire", 100, 25));
            items.add("Gold Coin");
        }
    }
    public LevelManager(){
        this.level = 1;
        this.enemies = new ArrayList<>();
        this.items = new ArrayList<>();
        initializeLevel();
    }
    public List<Enemy> getEnemies(){
        return enemies;
    }
    public List<String> getItems(){
        return items;
    }
    public void advanceLevel(){
        level++;
        if (level > 3) {
            System.out.println("The end!");
        } else {
            System.out.println("Level:" + level);
            initializeLevel();
        }
    }
    public int getLevel(){
        return level;
    }
}
