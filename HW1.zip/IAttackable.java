public interface IAttackable {
    void takeDamage(int damage);
    boolean isAlive();
}
