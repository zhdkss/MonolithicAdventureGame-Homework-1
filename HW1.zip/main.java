public class main {
    public static void main(String[] args) {
        Player player = new Player("Adventurer");
        CombatManager combatManager = new CombatManager();
        ItemManager itemManager = new ItemManager();
        LevelManager levelManager = new LevelManager();

        while (player.isAlive() && levelManager.getLevel() <= 3) {
            System.out.println("Level " + levelManager.getLevel());
            for (Enemy enemy : levelManager.getEnemies()) {
                combatManager.fight(player, enemy);
                if (!player.isAlive()) break;
            }

            for (String item : levelManager.getItems()) {
                player.addItem(item);
                itemManager.useItem(player, item);
            }

            if (player.isAlive()) {
                levelManager.advanceLevel();
            }
        }

        if (player.isAlive()) {
            System.out.println("Поздравляем! Вы завершили игру с " + player.getExperience() + " XP.");
        } else {
            System.out.println("Игра окончена. Попробуйте снова.");
        }
    }
}
