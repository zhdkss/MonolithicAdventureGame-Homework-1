public class Enemy implements IEnemy, IAttackable {
    private String type;
    private int health;
    private int attackDamage;

    public Enemy(String type, int health, int attackDamage) {
        this.type = type;
        this.health = health;
        this.attackDamage = attackDamage;
    }

    @Override
    public void takeDamage(int damage) {
        health -= damage;
        if (health < 0) health = 0;
    }

    @Override
    public boolean isAlive() {
        return health > 0;
    }

    @Override
    public int attack() {
        return attackDamage;
    }

    @Override
    public String getType() {
        return type;
    }
}
