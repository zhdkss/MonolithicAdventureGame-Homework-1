import java.util.HashMap;
import java.util.Map;

public class ItemManager {
    private Map<String, Integer> itemEffects;

    public ItemManager() {
        itemEffects = new HashMap<>();
        itemEffects.put("Elixir", 20);
        itemEffects.put("Sword", 15);
    }
    public void useItem(Player player, String item) {
        if (player.getInventory().contains(item)) {
            if (itemEffects.containsKey(item)) {
                player.heal(itemEffects.get(item));
                System.out.println("The player used " + item + ", restoring " + itemEffects.get(item) + " HP.");
            }
            player.getInventory().remove(item);
        } else {
            System.out.println("Player don't have this item.");
        }
    }
}
