public class CombatManager {
    public void fight(Player player, Enemy enemy) {
        while (player.isAlive() && enemy.isAlive()) {
            enemy.takeDamage(20); // игрок всегда наносит 20 урона
            if (enemy.isAlive()) {
                player.takeDamage(enemy.attack());
            }
        }

        if (player.isAlive()) {
            System.out.println("Victory!");
            player.gainExperience(50);
        } else {
            System.out.println("You DIED!");
        }
    }
}
