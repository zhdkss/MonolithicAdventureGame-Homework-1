public interface IEnemy {
    int attack();
    String getType();
}
